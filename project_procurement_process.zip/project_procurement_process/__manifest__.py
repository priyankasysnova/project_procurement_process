# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Project Procurement Process',
    'version': '1.0',
    'category': 'Project',
    'author':'priyankaaust15@gmail.com',
    'description': """
The project manager estimates the materials and time that required for the project to be
done. Multiple material requisitions can be generated against a project. The purchase
manager either generates PO against the requisitions or transfer materials from other
projects using odoo’s internal transfer process. The inventory manager will validate the
stock transfers. Every transaction should have an accounting impact.
In project form, there must be two tabs, one is for cost estimation and the other is for
real cost which will come from invoicing, so the company can see actual profit or loss
against a project.
    """,
    'summary': 'Create material requisitions against the projects.',
    'website': '',
    'images': ['static/description/icon.jpg'],
    'depends': ['mail'],
    'data': [
        'data/procurement_request_data.xml',
        'security/project_procurement_group.xml',
        'security/ir.model.access.csv',
        'views/project_procurement_process_view.xml',
        'views/project_view_extend.xml',
    ],
    'depends': ['project','purchase', 'account'],
    'installable': True,
    'auto_install': False,
    'application': True,
    'sequence': 105,
}
