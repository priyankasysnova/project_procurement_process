'''
Created on Feb 29, 2020

@author: priyanka
'''
from odoo import api, models, fields

import logging

_logger = logging.getLogger(__name__)


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"
    
    project_id = fields.Many2one('project.project',
        string='Project')
        
class StockPicking(models.Model):
    _inherit = "purchase.order"

    project_id = fields.Many2one('project.project',
        string='Project')



        

