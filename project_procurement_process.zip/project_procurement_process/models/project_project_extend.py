'''
Created on Feb 29, 2020

@author: priyanka
'''
from odoo import api, models, fields

import logging

_logger = logging.getLogger(__name__)


class PurchaseOrder(models.Model):
    _inherit = "project.project"
    
    
    @api.multi
    def _compute_debit_balance(self):
        for value in self:
            account = self.env['account.analytic.account'].search([('name', 'like', value.name)], limit=1)
            if account:
                value.real_cost = account.debit
    
    estimated_cost = fields.Float(string='Estimated Cost', default = 0.0)
    real_cost = fields.Monetary(compute='_compute_debit_balance', string='Real Cost')

    
    
